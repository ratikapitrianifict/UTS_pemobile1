import React from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  ScrollView,
  Image,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

export default function HomeScreen({ navigation, route }) {
  const userName = route?.params?.user || "USER";

  const handleLogout = () => {
    Alert.alert("Konfirmasi Logout", "Apakah Anda yakin ingin keluar?", [
      { text: "Batal", style: "cancel" },
      {
        text: "Keluar",
        style: "destructive",
        onPress: () => navigation.replace("Login"),
      },
    ]);
  };

  const handleMenuPress = (menuTitle) => {
    Alert.alert("Menu", `Anda memilih ${menuTitle}`);
  };

  const menus = [
    { id: "1", title: "MENU 1", icon: "grid-outline" },
    { id: "2", title: "MENU 1", icon: "layers-outline" },
    { id: "3", title: "MENU 1", icon: "folder-outline" },
    { id: "4", title: "MENU 1", icon: "settings-outline" },
  ];

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header Title: HOME PAGE */}
        <View style={styles.headerContainer}>
          <Text style={styles.headerTitle}>HOME PAGE</Text>
        </View>

        {/* Welcome Card dengan Foto Profil: WELCOME, USER */}
        <View style={styles.welcomeCard}>
          <Image
            source={require("../assets/Ririw.jpeg")}
            style={styles.avatar}
            resizeMode="cover"
          />
          <Text style={styles.welcomeText}>WELCOME, {userName}</Text>
        </View>

        {/* Grid Menu: 2x2 Grid Sesuai Sketsa */}
        <View style={styles.menuGrid}>
          {menus.map((item, index) => (
            <TouchableOpacity
              key={`${item.id}-${index}`}
              style={styles.menuCard}
              activeOpacity={0.7}
              onPress={() => handleMenuPress(`${item.title} #${index + 1}`)}
            >
              <View style={styles.iconCircle}>
                <Ionicons name={item.icon} size={24} color="#2563EB" />
              </View>
              <Text style={styles.menuText}>{item.title}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Tombol Logout Sesuai Sketsa */}
        <View style={styles.logoutContainer}>
          <TouchableOpacity
            style={styles.logoutButton}
            activeOpacity={0.8}
            onPress={handleLogout}
          >
            <Ionicons
              name="log-out-outline"
              size={18}
              color="#FFFFFF"
              style={styles.logoutIcon}
            />
            <Text style={styles.logoutButtonText}>TOMBOL LOGOUT</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F8FAFC",
  },
  scrollContent: {
    paddingHorizontal: 24,
    paddingTop: 30,
    paddingBottom: 40,
    flexGrow: 1,
  },
  headerContainer: {
    alignItems: "center",
    marginBottom: 20,
    paddingVertical: 8,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#1E293B",
    letterSpacing: 1.5,
  },
  welcomeCard: {
    backgroundColor: "#FFFFFF",
    borderWidth: 1.5,
    borderColor: "#CBD5E1",
    borderRadius: 14,
    paddingVertical: 20,
    paddingHorizontal: 20,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 26,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  avatar: {
    width: 84,
    height: 84,
    borderRadius: 42,
    borderWidth: 2.5,
    borderColor: "#2563EB",
    marginBottom: 12,
  },
  welcomeText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#2563EB",
    letterSpacing: 1.2,
    textAlign: "center",
  },
  menuGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    marginBottom: 30,
  },
  menuCard: {
    backgroundColor: "#FFFFFF",
    width: "47%",
    borderWidth: 1.5,
    borderColor: "#CBD5E1",
    borderRadius: 12,
    paddingVertical: 18,
    paddingHorizontal: 12,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  iconCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: "#EFF6FF",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },
  menuText: {
    fontSize: 15,
    fontWeight: "bold",
    color: "#334155",
    letterSpacing: 0.8,
  },
  logoutContainer: {
    alignItems: "center",
    marginTop: "auto",
  },
  logoutButton: {
    backgroundColor: "#EF4444",
    flexDirection: "row",
    borderRadius: 10,
    height: 48,
    paddingHorizontal: 28,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#EF4444",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 3,
  },
  logoutIcon: {
    marginRight: 8,
  },
  logoutButtonText: {
    color: "#FFFFFF",
    fontSize: 15,
    fontWeight: "bold",
    letterSpacing: 1,
  },
});