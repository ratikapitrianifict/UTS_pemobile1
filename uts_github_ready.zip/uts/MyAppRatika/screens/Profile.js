import { View, Text, StyleSheet, Image } from "react-native";
 
export default function ProfileScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.headerTitle}>My </Text>
      <Text style={styles.headerSubtitle}>Informasi profil mahasiswa</Text>
 
      <View style={styles.profileCard}>
        <Image
          source={require("../assets/Ririw.jpeg")}
          style={styles.avatar}
        />
 
        <Text style={styles.nameText}>Ratika Pitriani</Text>
 
        <View style={styles.infoBox}>
          <Text style={styles.infoLabel}>NIM</Text>
          <Text style={styles.infoValue}>4112755201250010</Text>
        </View>
 
        <View style={styles.infoBox}>
          <Text style={styles.infoLabel}>Program Studi</Text>
          <Text style={styles.infoValue}>S1 Informatika</Text>
        </View>
      </View>
    </View>
  );
}
 
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8FAFC",
    paddingHorizontal: 20,
    paddingTop: 55,
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: "bold",
    color: "#111827",
  },
  headerSubtitle: {
    fontSize: 14,
    color: "#6B7280",
    marginTop: 4,
    marginBottom: 25,
  },
  profileCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 18,
    padding: 24,
    alignItems: "center",
    elevation: 3,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
  },
  avatar: {
    width: 110,
    height: 110,
    borderRadius: 55,
    borderWidth: 3,
    borderColor: "#2563EB",
    marginBottom: 16,
  },
  nameText: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#111827",
    marginBottom: 24,
  },
  infoBox: {
    width: "100%",
    backgroundColor: "#F3F4F6",
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
    marginBottom: 14,
  },
  infoLabel: {
    fontSize: 12,
    color: "#9CA3AF",
    marginBottom: 4,
  },
  infoValue: {
    fontSize: 15,
    fontWeight: "600",
    color: "#111827",
  },
});